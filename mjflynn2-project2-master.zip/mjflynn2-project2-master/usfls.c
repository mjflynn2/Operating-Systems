/* _____________________________________________________________________________________
________________________________________________________________________________________*/

/* Author: Margot Flynn - CS326
 * File:     usfls.c
 *
 * Purpose:  Implement a ls function to list files in a given directory from
 * 			 from the usfsh.c shell.
 *
 * Compile:  gcc -g -o usfls usfls.c
 * Run:      ./usfls
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

void list_directory(DIR *my_directory);

int main(int argc, char* argv[]){

	DIR *my_directory = NULL;

	/* Sets directory to current working
	 directory if one is not given. */
	if ( argv[1] == NULL ){
		char cwd[1024];
		getcwd(cwd, sizeof(cwd));
		my_directory = opendir(cwd);
	}
	else{
		my_directory = opendir(argv[1]);
	}

	list_directory (my_directory);
}

void list_directory (DIR *my_directory){
	struct dirent *file = NULL;
	while((file = readdir(my_directory)) != NULL){
		if(file->d_name[0] != '.'){
			printf("%s\n", file->d_name);
		}	
	}

	closedir(my_directory);
}