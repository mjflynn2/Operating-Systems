/* _____________________________________________________________________________________
________________________________________________________________________________________*/

/* Author: Margot Flynn - CS326
 * File:     usfsh.c
 *
 * Purpose:  Implement a shell that can use basic and built-in UNIX calls 
 *			 and utilize the created usfls.c class for ls functionality.
 * 
 *
 * Compile:  gcc -g -o usfsh usfsh.c
 * Run:      ./usfsh
 */

// INCLUDE LIBRARIES _____________________________________________________________//

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

// GLOBAL VARIABLES _____________________________________________________________//

const char* REDIRECT = ">";
const char* PIPE = "|";
int counter;
int exit_status = 1;

// FUNCTION DEFINITIONS _____________________________________________________________//

void read_command_line(char* buf);
void shell_loop();
void tokenize( char* line, char** tokens);
void analyze( char **tokens );
int cd_launch(char** args);
int exit_launch(char** args);
int launch(char ** args);
int launch_redirect(char** main_args, char* file);
int launch_pipe(char** main_args, char** second_args);
int execute_simple(char** main_args);
int execute_pipe(char** main_args, char** second_args);
int execute_redirect(char** main_args, char* file);
char* chop(char *string);

// BUILT_IN VARIABLE ARRAYS _____________________________________________________________//

char *command_strings[] = {
	"cd", 
	"exit"
};

int (*command_launchers[2]) (char**) = {
	&cd_launch,
	&exit_launch
};

int main (int argc, char **argv) {
	shell_loop();
}

// MAIN LOOP _____________________________________________________________//

void shell_loop (void) {
	char ** args;
	int status;

	do {
		write (1, "$ ", 2);
		char *command_line = (char*) malloc(sizeof(char)*1024);
		read_command_line (command_line);

		char **tokenized_array = (char**) malloc(sizeof(char*)*1024);
		tokenize (command_line, tokenized_array);
		analyze (tokenized_array);

		memset(command_line, 0, sizeof(command_line));
		memset(tokenized_array, 0, sizeof(tokenized_array));


	}
	while (exit_status != 0);
}

// HELPER FUNCTIONS _____________________________________________________________//

void read_command_line (char* buf) {
	int MAXLINE = 1024;
	int position = 0;
	char c;

	while (read(STDIN_FILENO, &c, 1) > 0 && c != '\n') {
		buf[position] = c;
		position++;
	}

}

void tokenize (char* line, char** tokens) {
	counter = 0;
	const char TOKENIZER[1] = " ";

	char* token = strtok(line, TOKENIZER);
	while (token != NULL) {
		tokens[counter] = token;
		token = strtok(NULL, TOKENIZER);
		counter++;
	}
}

void analyze (char **tokens) {
	int i;
	int args = 0;
	int redirect = 1;
	int pipe = 1;

	char *main_args[100];

	for (i = 0; i < counter; i++) {

		if (strcmp(tokens[i], REDIRECT) == 0) {
			redirect = 0;
		}
		else if (strcmp(tokens[i], PIPE) == 0) {
			pipe = 0;
		}
		else {
			main_args[args] = tokens[i];
			args++;
		}

		if (pipe == 0 || redirect == 0) {
			break;
		}

		main_args[args] = NULL;
	}

	if (pipe == 0) {
		char *second_args[2];
		second_args[0] = tokens[i+1];
		second_args[1] = NULL;
		execute_pipe(main_args, second_args);
		memset(second_args, 0, sizeof(second_args));
	}

	else if (redirect == 0) {
		char* file = tokens[i+1];
		execute_redirect (main_args, file);
	}
	else {
		execute_simple (main_args);
	}

	memset(main_args, 0, sizeof(main_args));
}

// BUILT-IN LAUNCH FUNCTIONS _____________________________________________________//

int cd_launch (char** args) {

	if (args[1] == NULL) {
		fprintf (stderr, "expecting argument following cd command\n" );
	}
	else {
		if (chdir(args[1]) != 0) {
			fprintf (stderr, "could not execute cd command\n");
		}
	}
	return 1;
}

int exit_launch (char** args) {
	exit_status = 1;
	exit(0);
	return 0;
}

// LAUNCH FUNCTIONS _____________________________________________________________//

int launch (char ** args) {
	pid_t pid, wpid;
	int status;
	pid = fork();

	if (pid == 0) {
		if (execvp( args[0], args ) == -1) {
			perror( "shell" );
		}
		exit (EXIT_FAILURE);
	}
	else if (pid < 0) {
		perror("shell");
	} 
	id = wait(NULL);
	return 1;
}

int launch_pipe (char** main_args, char** second_args) {
	pid_t id;
	int count;
	int filedes[2];

	pipe(filedes);
	
	if ((id = fork()) == 0) {
		close(1);
		dup(filedes[1]);
		close(filedes[0]);

		if (execvp(main_args[0], main_args) < 0) {
			printf("execl main failed\n");
			exit(1);
		}

	}
	
	if ((id = fork()) == 0) {
		close(0);
		dup(filedes[0]);
		close(filedes[1]);

		if (execvp(second_args[0], second_args) < 0) {
			printf("execl second failed\n");
			exit(1);
		}

	}
	
	close(filedes[0]);
	close(filedes[1]);
	id = wait(NULL);
	id = wait(NULL);


}

int launch_redirect (char** main_args, char* file) {
	pid_t pid, wpid;
	int status;
	pid = fork();

	int file_direct = open(file, O_CREAT | O_TRUNC | O_WRONLY, 0644);
	    if (file_direct < 0) {
        printf("Cannot open %s\n", file);
        exit(1);
    }
	if (pid == 0) {
    	close(1);
		dup(file_direct);
		close(file_direct);

		if (execvp(main_args[0], main_args) == -1) {
			perror ("shell");
		}
		exit (EXIT_FAILURE);
	}
	else if (pid < 0){
		perror("shell");
	}
	id = wait(NULL);
	return 1;
}

// EXECUTE FUNCTIONS _____________________________________________________________//

int execute_simple (char** main_args) {
	int i;
	if (main_args[0] == NULL) {
		return 1;
	}

	for (i = 0; i < 2; i++) {
		if (strcmp(main_args[0], command_strings[i]) == 0) {
			return (*command_launchers[i])(main_args);
		}
	}

	return launch(main_args);
}

int execute_pipe(char** main_args, char** second_args){
	
	if(main_args[0] == NULL || second_args[0] == NULL){
		return 1;
	}

	return launch_pipe(main_args, second_args);
}

int execute_redirect (char** main_args, char* file) {
	if (main_args[0] == NULL || file == NULL) {
		return 1;
	}
	return launch_redirect(main_args, file);
}

/* _____________________________________________________________________________________
________________________________________________________________________________________
________________________________________________________________________________________*/
