/* Author: Margot Flynn - CS326
 * File:     usfsort.c
 *
 * Purpose:  Implement a sorted linked list to read words from one file,
 *           sort them, and print them to a different file.
 * 
 * Input:    File to read, and file to be written.
 *
 * Output:   A new file with a sorted list of the words from the original
 *           file.
 *
 * Compile:  gcc -g -o usfsort usfsort.c
 * Run:      ./usfsort
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

/*-----------------------------------------------------------------*
 * struct:     ListNode
 * Purpose:    struct to create a list node with stored word, 
 *             a pointer to the next & previous elements
 */
struct ListNode {
    struct ListNode *next;
    struct ListNode *prev;
    char *word;
} ListNode;

struct ListNode* insertNode(struct ListNode* head, char *word);
int readLine(int fd_in, char* buf, int length);

/*-----------------------------------------------------------------*
 * Function:   Insert
 * Purpose:    insert a single element into the list in the correct
               location so that the list will be in alphabetical order
 * Input arg:  word = word to be inserted into linked list
 */
struct ListNode* insertNode(struct ListNode* head, char *word){
    struct ListNode* newNode = malloc(sizeof(struct ListNode));
    newNode->word = malloc(sizeof(word));
    strcpy(newNode->word, word);
    struct ListNode* currNode = head;
    struct ListNode* predNode = NULL;

   while (currNode != NULL && strcmp(currNode->word, word) < 0) {
      predNode = currNode;
      currNode = currNode->next;
   }

   if(head == NULL){
    head = newNode;
    return head;
   }


   if(currNode == NULL && predNode != NULL){
    predNode->next = newNode;
    newNode->prev = predNode;
    return head;
   }

   if(predNode == NULL){
    head->prev=newNode;
    newNode->next = head;
    return newNode;
   }

   predNode->next=newNode;
   newNode->prev=predNode;
   newNode->next=currNode;
   currNode->prev=newNode;

  return head;
}
/*-----------------------------------------------------------------*
 * Function:   readLine
 * Purpose:    reads in a line from file character by character
 *             and appends them to a buffer to be added to the list 
 * Input arg:  fd_in - read file, buf - line buffer, length - length of buf
 */
int readLine(int fd_in, char* buf, int length){
  char c;
  int j = 0;
  int n = 1024;

    while(n = read(fd_in, &c, 1) > 0){
      buf[j] = c;
      if(c=='\n'){
        break;
      }
      j=j+1;
    }
  buf[j]='\n';
  return n;
}
/*-----------------------------------------------------------------*
*/
int main(int argc, char *argv[])
{
    int fd_in, fd_out;
    char buf[1024];
    

    //open read file
    fd_in = open(argv[1], O_RDONLY);
    if (fd_in < 0) {
        printf("Cannot open %s\n", argv[1]);
        exit(1);
    }


    struct ListNode* head = NULL;

    //while there are still characters in the file, lines are created and
    //inserted into the linked list
    int n = 1024;
    while(n > 0){
      memset(buf, 0, 1024);
      n = readLine(fd_in, buf, 1024);
      head = insertNode(head, buf);
    }
    
    // open write file
    fd_out = open(argv[2], O_CREAT | O_TRUNC | O_WRONLY, 0644);
    if (fd_out < 0) {
        printf("Cannot open %s\n", argv[2]);
        exit(1);
    }

    // print all nodes to write file
    struct ListNode* printNode = head;
    while(printNode != NULL){
        write(fd_out, printNode->word, strlen(printNode->word));
        printNode = printNode->next;
    }
    
    close(fd_in);
    close(fd_out);

    return 0;
}


