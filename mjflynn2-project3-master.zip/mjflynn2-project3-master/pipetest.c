#include "types.h" 
#include "stat.h" 
#include "user.h"
#include "fs.h"
#include "param.h"

#define NULL ( (void *) 0)

int main(int argc, char *argv[]){
	int filedes[2];
	pipe(filedes);

	printf(1, "Empty pipe has a length of %d\n", pipecount(filedes[1]));

	if (write(filedes[1], "Hello there!", 12) < 0){
		printf(1, "cannot write to pipe\n");
	}
	printf(1, "Half pipe has a length of %d\n", pipecount(filedes[1]));

	if (write(filedes[1], "ezibdqfzocuiayjkzjczvdlyxunt\
 			odzcjtrizvoycfjuzkynrofjcqjvcflipjvimmujmhn\
 			wtqqcopbcqkmlqbrpijkkdcgidefqsoytorxcyzqggk\
 			yvqyohjetxymvmukisychhdkkjocmcbaqbdfzbmrfpu\
 			rjlwbmserwlxctahcwmlmpyqjsxlkbjikeescwrckqg\
 			grhpietmkcfiocyotqendmdnnkzndjetwrxaitornxz\
 			ydvjaiojkdhftfweoipmrjdjdbdismofzdnwcfrzlfu\
 			xiskjcolkeqmuxinvotsckopqmsoloqjxqfiaiitmvf\
 			abvmamgpyigkcfughbajusawxgovpqooincrhjluius\
 			tcbmzwxnaketnylcnpyigsvkicbymhxdwqfbfltakum\
 			papmvvychdgtytkrastythcjpikyuudlguiypyijyih\
 			yjccijxyejnuccclmhtrnaskyfrdfflxayhwarfqgt", 500) < 0){
		printf(1, "cannot write to pipe\n");
	}
	printf(1, "Full pipe has a length of %d\n", pipecount(filedes[1]));

	printf(1, "Invalid pipe has a length of %d\n", pipecount(13));

	exit();
	return 0;
}
