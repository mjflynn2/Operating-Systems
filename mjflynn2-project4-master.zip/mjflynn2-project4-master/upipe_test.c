#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"
#include "upipe.h"

#define NULL (void *) 0

int main(int argc, char **argv)
{
    struct upipe *p;
    char data[512];
    int id;
    int i;
    int j;

    p = upipe_create(4096, (void*)0x40000000); /* at 1GB */

    if (p == NULL) {
        printf(1, "Cannot create upipe, exiting\n");
        return -1;
        exit();
    }

    printf(1, "Created successfully\n"); 

    id = fork();

    if (id == 0) {
        /* in child */
        printf(1, "In child\n");
        p = upipe_attach((void*)0x48000000); /* at 1.5 GB */
        if (p == NULL) {
            printf(1, "Cannot attach to a upipe, exiting\n");
        }
        printf(1, "Attached\n");

        /* fill a 512 buffer with 'x's */
        for (i = 0; i < 512; i++) {
            data[i] = 'x';
        }

        printf(1, "Writing\n");
        for (i = 0; i < 10; i++) {
            if (upipe_write(p, data, 512) < 0) {
                printf(1, "upipe_write failure, exiting.\n");
                return -1;
                exit();
            }
            printf(1, "Pipe written\n");
        }

        upipe_detach(p);
        exit();
    }
    // wait();
    printf(1, "Reading\n");
    for (i = 0; i < 10; i++) {
        if (upipe_read(p, data, 512) < 0) {
            printf(1, "upipe_read failure, exiting.\n");
        }
        for (j = 0; j < 512; j++) {
            if (data[j] != 'x') {
                printf(1, "Did not receive data correctly from upipe, expected all 'x' values, exiting.\n");
                exit();
            }
        }
    }

    upipe_detach(p);
    printf(1, "upipe test finished\n");
    exit();
    return 0;
}
