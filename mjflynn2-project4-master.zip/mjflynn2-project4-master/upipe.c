#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"
#include "upipe.h"
// #include "defs.h"
// #include "param.h"
// #include "mmu.h"
// #include "proc.h"

#define NULL (void *) 0

struct upipe *upipe_create(int size, void *vaddr){

	int npages = (size / 4096) + 4;
	printf(1, "Npages = %d\n", npages);
	if(mmap_alloc(vaddr, npages) == 0){
		void *pipe_addr = vaddr + (3 * 4096);
		struct upipe *p; 
		p = (struct upipe*)pipe_addr;
		p->nwrite = 0;
		p->nread = 0;
		p->pipesize = size;
		lock_init(vaddr, 0);
		cond_init(vaddr + 4096); //Full
		cond_init(vaddr + (2 * 4096)); //Empty

		return p;
	}
	return NULL;
}

struct upipe *upipe_attach(void *vaddr){

	mmap_attach(vaddr);

	void *pipe_addr = vaddr + (3 * 4096);
	struct upipe *p;
	p = (struct upipe*) pipe_addr;
	return p;
}

int upipe_detach(struct upipe *p){
	mmap_detach();
	return 0;
}

int upipe_write(struct upipe *p, char *buf, int n){
	int i;
	void *lock_addr = ((void*) p) - (3 * 4096);
	void *full_addr = ((void*) p) - (2 * 4096);
	void *empty_addr = ((void*) p) - 4096;
	char *data_addr = ((void*) p) + 4096;

	printf(1, "cond x = %d\n", *((int*) empty_addr));
	printf(1, "IN upipe_write\n");
	lock_acquire(lock_addr);
	printf(1, "Lock acquired\n");
	for(i = 0; i < n; i++){
		// printf(1, "In write for loop. nwrite = %d\n", p->nwrite);
		while(p->nwrite == p->nread + p->pipesize){
			printf(1, "Before cond_signal\n");
			cond_signal(empty_addr);
			printf(1, "Before cond_wait\n");
			cond_wait(full_addr, lock_addr);
		}
		data_addr[p->nwrite++ % p->pipesize] = buf[i];
	}
	printf(1, "Before cond_signal second\n");
	cond_signal(empty_addr);
	lock_release(lock_addr);
	printf(1, "Write finished\n");
	return n;
}

int upipe_read(struct upipe *p, char *buf, int n){
	int i;
	void *lock_addr = ((void*) p) - (3 * 4096);
	void *full_addr = ((void*) p) - (2 * 4096);
	void *empty_addr = ((void*) p) - 4096;
	char *data_addr = ((void*) p) + 4096;

	printf(1, "Reading from pipe\n");

	lock_acquire(lock_addr);
	while(p->nread == p->nwrite){
		cond_wait(empty_addr, lock_addr);
	}
	for(i = 0; i < n; i++){
		// printf(1, "In read for loop. nread = %d and nwrite = %d\n", p->nread, p->nwrite);
    	if(p->nread == p->nwrite)
     		break;
		buf[i] = data_addr[p->nread++ % p->pipesize];
	}
	cond_signal(full_addr); 
	lock_release(lock_addr);
	printf(1, "Read finished\n");
	return i;
}
// try smaller data sizes - incremement with success
// 


